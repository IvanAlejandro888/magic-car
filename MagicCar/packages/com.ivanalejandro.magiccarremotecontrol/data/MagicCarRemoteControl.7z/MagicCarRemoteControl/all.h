#ifndef ALL_H
#define ALL_H

#include "qtlibraries.h"
#include "network.h"

#endif // ALL_H
