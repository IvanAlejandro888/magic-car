#ifndef QTLIBRARIES_H
#define QTLIBRARIES_H

#include <QMainWindow>
#include <QInputDialog>
#include <QMessageBox>

#endif // QTLIBRARIES_H
