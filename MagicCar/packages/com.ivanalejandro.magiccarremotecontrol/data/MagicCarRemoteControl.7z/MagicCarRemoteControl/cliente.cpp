int crearSocket
